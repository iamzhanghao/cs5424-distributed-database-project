cqlsh -f schema/cassandra/schema_a.cql xcnd30.comp.nus.edu.sg 3042
cqlsh -f schema/cassandra/schema_b.cql xcnd30.comp.nus.edu.sg 3042